#!/bin/sh

javac MyBot.java
./halite -d "240 160" "java MyBot" "java MyBot"